DROP TABLE users;
CREATE TABLE users(		
				user_id 	VARCHAR2(4)		PRIMARY KEY, 
				password 	VARCHAR2(10)		NOT NULL,
				role 		VARCHAR2(10)	NOT NULL, 
				user_name 	VARCHAR2 (20)	UNIQUE,
				mobile_no 	VARCHAR2(10)	UNIQUE,
				phone 		VARCHAR2(10),
				address 	VARCHAR2(25)	NOT NULL, 
				email 		VARCHAR2(50)	UNIQUE
);


INSERT INTO users (user_id,password,role,user_name,mobile_no,address,email)  
VALUES ('1010','prasanth','admin','venkat prasanth','7736780735','Vizag','k.v.prasanth176@gmail.com');



DROP TABLE hotel;
CREATE TABLE hotel(
				hotel_id 			VARCHAR2(4)		PRIMARY KEY, 
				city 				VARCHAR2(10)	NOT NULL,
				hotel_name 			VARCHAR2(20)	NOT NULL,
				address				VARCHAR2(25)	NOT NULL, 
				description 		VARCHAR2(50)	NOT NULL, 
				avg_rate_per_night 	NUMBER(6,2)		NOT NULL, 
				phone_no1 			VARCHAR2(10)	UNIQUE,
				phone_no2 			VARCHAR2(10)	UNIQUE, 
				rating 				VARCHAR2(4)		NOT NULL, 
				email				VARCHAR2(15)	NOT NULL, 
				fax 				VARCHAR2(15)	
				);

DROP TABLE roomdetails;
CREATE TABLE roomdetails(
				room_id 		VARCHAR2(4)		PRIMARY KEY,
				room_no 		VARCHAR2(3)		UNIQUE, 
				room_type 		VARCHAR2(20)	NOT NULL,
				per_night_rate 	NUMBER(6,2)		NOT NULL,
				availability 	NUMBER(1)		NOT NULL,
				hotel_id 		VARCHAR2(4), 
				FOREIGN KEY (hotel_id) REFERENCES hotel (hotel_id)
);

DROP TABLE bookingdetails;
CREATE TABLE bookingdetails(
				booking_id 		VARCHAR2(5)		PRIMARY KEY,	 
				booked_from 	DATE			NOT NULL,
				booked_to 		DATE			NOT NULL, 
				no_of_adults 	NUMBER			NOT NULL, 
				no_of_children 	NUMBER, 
				amount 			NUMBER(6,2)		NOT NULL,
				room_id			VARCHAR2(4),
				user_id 		VARCHAR2(4)	,
				FOREIGN KEY (room_id) REFERENCES roomdetails(room_id), 
				FOREIGN KEY (user_id) REFERENCES users(user_id)
);

DROP SEQUENCE user_id_seq;

CREATE SEQUENCE user_id_seq
START WITH 1001
INCREMENT BY 1
MAXVALUE 1200
;

DROP SEQUENCE hotel_id_seq;

CREATE SEQUENCE hotel_id_seq
START WITH 1
INCREMENT BY 1
MAXVALUE 60
;

DROP SEQUENCE room_id_seq;

CREATE SEQUENCE room_id_seq
START WITH 101
INCREMENT BY 1
MAXVALUE 600
;

DROP SEQUENCE booking_id_seq;

CREATE SEQUENCE booking_id_seq
START WITH 10001
INCREMENT BY 1
MAXVALUE 50000
;


