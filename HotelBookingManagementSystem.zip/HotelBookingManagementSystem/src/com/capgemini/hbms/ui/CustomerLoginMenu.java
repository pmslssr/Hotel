package com.capgemini.hbms.ui;

public enum CustomerLoginMenu {

	SEARCH,BOOK_HOTEL,CHECK_STATUS,EXIT;
}
