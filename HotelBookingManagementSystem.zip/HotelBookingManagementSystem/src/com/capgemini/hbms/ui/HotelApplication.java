package com.capgemini.hbms.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.capgemini.hbms.bean.BookingDetails;
import com.capgemini.hbms.bean.Hotel;
import com.capgemini.hbms.bean.RoomDetails;
import com.capgemini.hbms.bean.Users;
import com.capgemini.hbms.exception.HotelException;
import com.capgemini.hbms.service.HotelServiceImpl;
import com.capgemini.hbms.service.IHotelService;

public class HotelApplication {

	public static void main(String[] args) {

		IHotelService service = new HotelServiceImpl();
		Scanner scanner = new Scanner(System.in);
		PropertyConfigurator.configure("resources/log4j.properties");

		UserMenu choice = null;
		AdminMenu adminChoice = null;
		CustomerMenu custChoice = null;
		CustomerLoginMenu custLoginChoice = null;
		int operation = 0;

		try {
			while (choice != UserMenu.EXIT) {
				System.out
						.println("************  HOTEL BOOKING MANAGEMENT SYSTEM  **************");
				System.out.println("CHOICE\t MENU");
				System.out
						.println("***********************************************************");
				for (UserMenu menuItem : UserMenu.values()) {
					System.out.println(menuItem.ordinal() + "\t"
							+ menuItem.name());
				}

				System.out.println("Enter Choice: ");
				int ordinal = scanner.nextInt();
				if (ordinal < 0 || ordinal > UserMenu.EXIT.ordinal()) {
					System.err.println("Invalid Choice");
					continue;
				}
			

				choice = UserMenu.values()[ordinal];

				switch (choice) {

				case ADMIN:

					System.out.println("Enter your UserId:");
					int adminId = scanner.nextInt();
					System.out.println("Enter your Password");
					String adminPassword = scanner.next();

					boolean loginStatus = service.verifyLogin(adminId,
							adminPassword);
					if (loginStatus == true) {

						while (adminChoice != AdminMenu.EXIT) {
							System.out.println("CHOICE\t MENU");
							System.out
									.println("***********************************************************");
							for (AdminMenu menuItem : AdminMenu.values()) {
								System.out.println(menuItem.ordinal() + "\t"
										+ menuItem.name());
							}

							System.out.println("Enter Choice: ");
							int ordinal1 = scanner.nextInt();
							if (ordinal1 < 0
									|| ordinal1 > AdminMenu.EXIT.ordinal()) {
								System.err.println("Invalid Choice");
								continue;
							}

							adminChoice = AdminMenu.values()[ordinal1];

							switch (adminChoice) {

							case MANAGE_HOTELS:
								System.out.println(adminChoice);
								while (operation < 4) {
									System.out.println("Choices");
									System.out.println("1.Add Hotel\n"
											+ "2.Delete Hotel\n"
											+ "3.Modify Hotel\n" + "4.Exit\n");
									System.out.println("Enter Operations!!!");
									operation = scanner.nextInt();
									switch (operation) {

									case 1:

										Hotel hotel = new Hotel();

										System.out.println("Enter Hotel Name");
										hotel.setHotelName(scanner.next());
										System.out.println("Enter City");
										hotel.setCity(scanner.next());
										System.out.println("Enter Address");
										hotel.setAddress(scanner.next());
										System.out.println("Enter Description");
										hotel.setDescription(scanner.next());
										System.out
												.println("Enter Average Rate Per night");
										hotel.setAvgRatePerNight(scanner
												.nextDouble());
										System.out.println("Enter Phone No 1 ");
										hotel.setPhoneNo1(scanner.next());
										System.out.println("Enter Phone No 2 ");
										hotel.setPhoneNo2(scanner.next());
										System.out
												.println("Enter Rating On A scale of 5");
										hotel.setRating(scanner.nextInt());
										System.out.println("Enter Email");
										hotel.setEmail(scanner.next());
										System.out.println("Enter Fax");
										hotel.setFax(scanner.next());
										try {
											int curr_id = service
													.addHotel(hotel);
											if (curr_id > 0) {
												System.out
														.println("Hotel Added with HotelId: "
																+ curr_id
																+ " .");
											} else {
												System.out
														.println("Hotel could not be added");
											}
										} catch (HotelException exp) {
											System.err
													.println(exp.getMessage());
										}
										break;

									case 2:

										try {
											System.out.println("Enter HotelId");
											int hotelId = scanner.nextInt();
											boolean isSuccessful = service
													.deleteHotel(hotelId);
											if (isSuccessful) {
												System.out
														.println("Contact Deleted");
											} else {
												System.out
														.println("Contact could not be deleted");
											}

										} catch (HotelException exp) {
											System.err
													.println(exp.getMessage());
										}
										break;

									case 3:
										System.out.println("modify");
										System.out
												.println("Enter the hotel id you want to update");
										int hid = scanner.nextInt();
										System.out
												.println("Enter Updated Description");
										String hotelDesc = scanner.next();
										System.out
												.println("Enter Updated Average Rate Per night");
										double avgRate = scanner.nextDouble();
										try {
											boolean isSuccessful = service
													.modifyHotel(hotelDesc,
															avgRate, hid);
											if (isSuccessful) {
												System.out
														.println("Hotel Modified");
											} else {
												System.out
														.println("Hotel could not be modified");
											}

										} catch (HotelException exp) {
											System.err
													.println(exp.getMessage());
										}
										break;

									case 4:
										break;
									}
								}
								operation = 0;
								break;

							case MANAGE_ROOMS:
								while (operation < 4) {
									System.out.println("Choices");
									System.out.println("1.Add Room\n"
											+ "2.Delete Room\n"
											+ "3.Modify Room\n" + "4.Exit\n");
									System.out.println("Enter Operations!!!");
									operation = scanner.nextInt();
									switch (operation) {
									case 1:

										RoomDetails room = new RoomDetails();

										System.out.println("Enter Hotel Id");
										room.setHotelId(scanner.nextInt());
										System.out.println("Enter Room No");
										room.setRoomNo(scanner.nextInt());
										System.out.println("Enter Room Type");
										room.setRoomType(scanner.next());
										System.out
												.println("Enter Rate Per Night");
										room.setPerNightRate(scanner
												.nextDouble());
										System.out.println("Availability");
										room.setAvailability(scanner.nextInt());
										try {
											int curr_id = service.addRoom(room);
											if (curr_id > 0) {
												System.out
														.println("Room Added with RoomId: "
																+ curr_id
																+ " .");
											} else {
												System.out
														.println("Room could not be added");
											}
										} catch (HotelException exp) {
											System.err
													.println(exp.getMessage());
										}
										break;
									case 2:

										try {
											System.out.println("Enter RoomId");
											int roomId = scanner.nextInt();
											boolean isSuccessful = service
													.deleteRoom(roomId);
											if (isSuccessful) {
												System.out
														.println("Room Deleted");
											} else {
												System.out
														.println("Room could not be deleted");
											}

										} catch (HotelException exp) {
											System.err
													.println(exp.getMessage());
										}
										break;
									case 3:

										try {
											System.out.println("Enter RoomId");
											int roomId = scanner.nextInt();
											System.out
													.println("Enter Revised Tariff");
											double rent = scanner.nextDouble();
											boolean isSuccessful = service
													.modifyRoom(roomId, rent);
											if (isSuccessful) {
												System.out
														.println("Room Updated");
											} else {
												System.out
														.println("Room could not be updated");
											}

										} catch (HotelException exp) {
											System.err
													.println(exp.getMessage());
										}
										break;
									case 4:
										break;
									}
								}
								operation = 0;
								break;

							case GENERATE_REPORTS:
								while (operation < 5) {
									System.out.println("Choices");
									System.out
											.println("1.List Of Hotels\n"
													+ "2.Booking Details By Hotel ID\n"
													+ "3.Guest List By Hotel ID\n"
													+ "4.List of Booking Details By Date\n"
													+ "5.Exit\n");
									System.out.println("Enter Operations....");
									operation = scanner.nextInt();
									switch (operation) {
									case 1:

										try {
											List<Hotel> hotels = service
													.getHotelList();
											System.out
													.println("******************************************************************HOTEL DETAILS*****************************************************************************");
											System.out
													.println("************************************************************************************************************************************************************");
											  System.out.println("HOTEL ID" +
											  "\t" + "HOTEL NAME" + "\t" +
											  "CITY" + "\t\t" + "ADDRESS" +
											  "\t\t" + "DESCRIPTION" + "\t" +
											  "RATE PER NIGHT" + "\t" +
											  "PHONE 01" + "\t" + "PHONE 02" +
											  "\t" + "RATING" + "\t" + "EMAIL"
											  + "\t\t" + "FAX");
											  System.out.println(
											  "-------------------------------------------------------------------------------------------------------------------------------------------------------------"
											  );
											for (Hotel hotel2 : hotels) {
												System.out.println(hotel2);
											}
										} catch (HotelException exp) {
											System.err
													.println(exp.getMessage());
										}
										break;
									case 2:

										try {
											System.out
													.println("Enter hotel Id");
											List<BookingDetails> bookingDetails = service
													.getBookingDetails(scanner
															.nextInt());
											System.out
													.println("******************************************************************BOOKING DETAILS***********************************************************************");
											System.out
													.println("********************************************************************************************************************************************************");

											System.out.println("BOOKING ID"
													+ "\t" + "ROOM ID" + "\t\t"
													+ "USER ID" + "\t\t"
													+ "BOOKED FROM" + "\t"
													+ "BOOKED TO" + "\t"
													+ "NUMBER OF ADULTS" + "\t"
													+ "NUMBER OF CHILDREN"
													+ "\t" + "AMOUNT");
											System.out
													.println("--------------------------------------------------------------------------------------------------------------------------------------------------------");

											if (bookingDetails.isEmpty()) {
												System.out
														.println("No Records Found");
											} else {
												for (BookingDetails bookingData : bookingDetails) {
													System.out
															.println(bookingData);
												}
											}
										} catch (HotelException exp) {
											System.err
													.println(exp.getMessage());
										}
										break;
									case 3:

										try {
											System.out.println("Enter HotelId");
											int hotel_Id = scanner.nextInt();
											List<Users> guestName = service
													.getGuestListByHotel_Id(hotel_Id);
											if (guestName.isEmpty()) {
												System.out
														.println("No Records Available");
											} else {
												for (Users guestlist : guestName) {
													System.out
															.print("GUEST NAME:  "
																	+ guestlist
																			.getUserName());
													System.out
															.println("\tGUEST ID  :  "
																	+ guestlist
																			.getUserId());
												}
											}

										} catch (HotelException exp) {
											System.err
													.println(exp.getMessage());
										}
										break;
									case 4:
										try {
											DateTimeFormatter formatter = DateTimeFormatter
													.ofPattern("d/MM/yyyy");
											LocalDate mainDate = null;
											System.out
													.println("Enter Booking Date In the Format dd/MM/yyyy ");
											String date = scanner.next();
											mainDate = LocalDate.parse(date,
													formatter);
											List<BookingDetails> bookingDetails = service
													.getBookingDetailsByDate(mainDate);
											System.out
											.println("******************************************************************BOOKING DETAILS***********************************************************************");
											System.out
													.println("********************************************************************************************************************************************************");

											System.out.println("BOOKING ID"
													+ "\t" + "ROOM ID" + "\t\t"
													+ "USER ID" + "\t\t"
													+ "BOOKED FROM" + "\t"
													+ "BOOKED TO" + "\t"
													+ "NUMBER OF ADULTS" + "\t"
													+ "NUMBER OF CHILDREN"
													+ "\t" + "AMOUNT");
											System.out
													.println("--------------------------------------------------------------------------------------------------------------------------------------------------------");

											if (bookingDetails.isEmpty()) {
												System.out
														.println("No Records Available");
											} else {
												for (BookingDetails bookingData : bookingDetails) {
													System.out
															.println(bookingData);
												}
											}
										} catch (HotelException exp) {
											System.err
													.println(exp.getMessage());
										}
										break;
									case 5:
										break;
									}
								}
								operation = 0;
								break;

							case EXIT:
								break;

							}
						}
					} else {
						System.out.println("Unauthorised Access!!!");
					}
					break;

				case CUSTOMER:
					while (custChoice != CustomerMenu.EXIT) {
						System.out.println("CHOICE\t MENU");
						System.out
								.println("***********************************************************");
						for (CustomerMenu menuItem : CustomerMenu.values()) {
							System.out.println(menuItem.ordinal() + "\t"
									+ menuItem.name());
						}

						System.out.println("Enter Choice: ");
						int ordinal1 = scanner.nextInt();
						if (ordinal1 < 0
								|| ordinal1 > CustomerMenu.EXIT.ordinal()) {
							System.err.println("Invalid Choice");
							continue;
						}

						custChoice = CustomerMenu.values()[ordinal1];

						switch (custChoice) {

						case REGISTER:
							Users user = new Users();
							System.out.println("Enter the User Name: ");
							user.setUserName(scanner.next());
							System.out.println("Enter Mobile Number: ");
							user.setMobileNo(scanner.next());
							System.out.println("Enter Phone Number: ");
							user.setPhone(scanner.next());
							System.out.println("Enter Email");
							user.setEmail(scanner.next());
							System.out.println("Enter Address");
							user.setAddress(scanner.next());
							System.out.println("Set Your Password");
							user.setPassword(scanner.next());
							try {
								int curr_id = service.addUser(user);
								if (curr_id > 0) {
									System.out
											.println("Customer Added with Customer_Id: "
													+ curr_id + " .");
								} else {
									System.out
											.println("Customer could not be added");
								}
							} catch (HotelException exp) {
								System.err.println(exp.getMessage());
							}
							break;
						case LOGIN:

							System.out.println("Enter your UserId:");
							int userId = scanner.nextInt();
							System.out.println("Enter your Password");
							String userPassword = scanner.next();

							boolean loginStatusUser = service.verifyCustLogin(
									userId, userPassword);
							if (loginStatusUser == true) {
								while (custLoginChoice != CustomerLoginMenu.EXIT) {
									System.out.println("CHOICE\t MENU");
									System.out
											.println("***********************************************************");
									for (CustomerLoginMenu menuItem : CustomerLoginMenu
											.values()) {
										System.out.println(menuItem.ordinal()
												+ "\t" + menuItem.name());
									}

									System.out.println("Enter Choice: ");
									int ordinal2 = scanner.nextInt();
									if (ordinal2 < 0
											|| ordinal2 > CustomerLoginMenu.EXIT
													.ordinal()) {
										System.err.println("Invalid Choice");
										continue;
									}

									custLoginChoice = CustomerLoginMenu
											.values()[ordinal2];

									switch (custLoginChoice) {
									case SEARCH:
										System.out.println("Enter City: ");
										List<Hotel> listByCity = service
												.getHotelListByCity(scanner
														.next());
										for (Hotel hotel2 : listByCity) {
											System.out.println(hotel2
													.toString());
										}
										System.out.println("Enter Hotel Id: ");
										int id = scanner.nextInt();
										System.out
												.println("Enter Room Type (AC/NON_AC): ");
										String type = scanner.next();
										List<RoomDetails> listByHotelIdAndType = service
												.getRoomListByHotelIdAndType(
														id, type);
										if (listByHotelIdAndType.isEmpty()) {
											System.out
													.println("No Rooms Available");
										} else {
											for (RoomDetails roomList : listByHotelIdAndType) {
												System.out.println(roomList
														.toString());
											}
										}
										break;
									case BOOK_HOTEL:

										BookingDetails bookingDetails = new BookingDetails();

										System.out
												.println("Enter Customer Id: ");
										bookingDetails.setUserId(scanner
												.nextInt());
										System.out.println("Enter Room Id: ");
										int room_id = scanner.nextInt();
										bookingDetails.setRoomId(room_id);
										System.out
												.println("Enter Check In Date(dd-MMM-yy): ");
										String from = scanner.next();
										System.out
												.println("Enter Check Out Date(dd-MMM-yy): ");
										String to = scanner.next();
										System.out
												.println("Enter No Of Adults: ");
										int noOfPerson = scanner.nextInt();
										bookingDetails
												.setNoOfAdults(noOfPerson);
										System.out
												.println("Enter No of Children: ");
										bookingDetails.setNoOfChildren(scanner
												.nextInt());

										double amount = service
												.calculateBookingAmount(
														room_id, from, to,
														noOfPerson);

										System.out.println(amount);
										DateTimeFormatter formatter = DateTimeFormatter
												.ofPattern("d/MM/yyyy");
										LocalDate checkIn = null;
										LocalDate checkOut = null;
										checkIn = LocalDate.parse(from,
												formatter);
										checkOut = LocalDate.parse(to,
												formatter);
										bookingDetails.setBookedFrom(checkIn);
										bookingDetails.setBookedTo(checkOut);
										bookingDetails.setAmount(amount);

										try {
											int curr_id = service
													.addBookingDetails(bookingDetails);
											if (curr_id > 0) {
												System.out
														.println("Booking Details Added with Booking Id: "
																+ curr_id
																+ " .");
												int update = service
														.updateRoomAvailability(room_id);
												if (update == 1) {
													System.out
															.println("Save this Id for Future references");
												}
											} else {
												System.out
														.println("Booking Details could not be added");
											}
										} catch (HotelException exp) {
											System.err
													.println(exp.getMessage());
										}

										break;
									case CHECK_STATUS:
										System.out.println("Enter Booking Id");
										int bId = scanner.nextInt();
										System.out
												.println("Your Booking Details");
										System.out
												.println("*****************************************************************");

										List<BookingDetails> listByBookingId = service
												.getBookingDetailsByBookingId(bId);
										if (listByBookingId.isEmpty()) {
											System.out
													.println("No Records Found");
										} else {
											for (BookingDetails BookingByHotelId : listByBookingId) {
												System.out
														.println(BookingByHotelId
																.toString());
											}
										}
										break;
									case EXIT:
										break;

									}
								}
							} else {
								System.out.println("Unauthorised Access!!!");
							}
							break;
						case EXIT:
							break;
						}
					}
					break;

				case EXIT:
					System.exit(0);
				}

			}

		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
	}
}

/*
 * public boolean doAdminLogin(){ System.out.println("Enter your UserId:"); int
 * adminId=scanner.nextInt(); System.out.println("Enter your Password"); String
 * adminPassword=scanner.next();
 * 
 * return service.verifyLogin(adminId, adminPassword);
 * 
 * }
 * 
 * public void doCustomerLogin(){
 * 
 * }
 * 
 * public void doRegister(){
 * 
 * }
 * 
 * //Admin //Hotel Management
 * 
 * public void doAdminAddHotel(){
 * 
 * }
 * 
 * public void doAdminDeleteHotel(){
 * 
 * }
 * 
 * public void doAdminModifyHotel(){
 * 
 * }
 * 
 * //Room Management
 * 
 * public void doAdminAddRoom(){
 * 
 * }
 * 
 * public void doAdminDeleteRoom(){
 * 
 * }
 * 
 * public void doAdminModifyRoom(){
 * 
 * }
 * 
 * //Generate Report public void doAdminListOfHotels(){
 * 
 * }
 * 
 * public void doAdminBookingDetailByHotelId(){
 * 
 * }
 * 
 * public void doAdminBookingDetailByBookingDate(){
 * 
 * }
 * 
 * public void doAdminGuestListByHotelId(){
 * 
 * }
 * 
 * //Customer public void doUserSearchHotel(){
 * 
 * }
 * 
 * public void doUserBookHotel(){
 * 
 * }
 * 
 * public void doUserBookingStatus(){
 * 
 * } }
 */

